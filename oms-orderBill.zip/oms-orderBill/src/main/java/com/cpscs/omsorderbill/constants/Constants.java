package com.cpscs.omsorderbill.constants;

/**
 * @version V1.0
 */
public class Constants {

     public static final Integer PAGE=1;
     public static final Integer LIMIT = 10;
}
